import React from 'react';
import { Star, Zap, DollarSign, Award } from 'lucide-react';

const About: React.FC = () => {
  const highlights = [
    {
      icon: DollarSign,
      title: 'מחיר מתחת למחירי השוק',
      description: 'איכות גבוהה במחיר משתלם'
    },
    {
      icon: Zap,
      title: 'מוצר מוגמר כולל הכל',
      description: 'מהרעיון ועד ההשקה'
    },
    {
      icon: Star,
      title: 'עבודה מהירה ואיכותית',
      description: 'תוצאות תוך זמן קצר'
    },
    {
      icon: Award,
      title: 'שירות מקצועי',
      description: 'ליווי מלא לאורך כל הדרך'
    }
  ];

  return (
    <section className="section about" id="about">
      <div className="container">
        <h2 className="section-title">אודות <span>אלעד</span></h2>
        <p className="section-subtitle">
          רקע אמנותי בכתיבה ומוזיקה, ניסיון חדשנות ויזמות מעל 25 שנה בסטארט-אפים מצליחים וניהול חשבונות סייבר בהיקף מיליונים
        </p>

        <div className="about-content">
          {/* Image Section */}
          <div className="about-image">
            <div>
              <Star size={64} />
              <p>תמונת אלעד</p>
            </div>
          </div>

          {/* Content Section */}
          <div className="about-text">
            <h3>מחבר בין יצירתיות לחדשנות טכנולוגית</h3>
            <p>
              אלעד קרן מביא פתרונות דיגיטליים עם AI, קריינות בכל השפות ופרודוקציות וידאו וקליפים. 
              עם רקע אמנותי עשיר וניסיון טכנולוגי מתקדם, אלעד יוצר חוויות דיגיטליות ייחודיות 
              שמשלבות יצירתיות עם חדשנות טכנולוגית.
            </p>

            {/* Highlights Grid */}
            <div className="highlights">
              {highlights.map((highlight) => (
                <div key={highlight.title} className="highlight">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{ 
                      width: '2.5rem', 
                      height: '2.5rem', 
                      background: 'rgba(168, 85, 247, 0.2)', 
                      borderRadius: '0.5rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <highlight.icon size={20} color="#a855f7" />
                    </div>
                    <div>
                      <h4 style={{ color: 'white', fontWeight: '600', fontSize: '0.875rem' }}>
                        {highlight.title}
                      </h4>
                      <p style={{ color: '#9ca3af', fontSize: '0.75rem' }}>
                        {highlight.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About; 