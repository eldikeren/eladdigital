import React from "react";
import { motion } from "framer-motion";
import { Code, Search, Target, Brush, BarChart2, Globe } from "lucide-react";

const services = [
  {
    id: 1,
    title: "בניית אתרים",
    description: "פיתוח אתרים מותאמים אישית עם דגש על חוויית משתמש וביצועים מעולים.",
    icon: Code,
  },
  {
    id: 2,
    title: "קידום אתרים (SEO)",
    description: "שיפור דירוג האתר בגוגל עם אופטימיזציה מתקדמת לתוצאות אורגניות.",
    icon: Search,
  },
  {
    id: 3,
    title: "ניהול קמפיינים",
    description: "ניהול מקצועי של קמפיינים בגוגל, פייסבוק ופלטפורמות נוספות.",
    icon: Target,
  },
  {
    id: 4,
    title: "עיצוב UX/UI",
    description: "עיצובים מודרניים ומדויקים שמושכים את המשתמשים ומשדרים יוקרה.",
    icon: Brush,
  },
  {
    id: 5,
    title: "אנליטיקה ודאטה",
    description: "מעקב וניתוח ביצועים בזמן אמת לקבלת החלטות מבוססות נתונים.",
    icon: BarChart2,
  },
  {
    id: 6,
    title: "אסטרטגיה דיגיטלית",
    description: "בניית תוכנית פעולה חכמה לשיווק דיגיטלי שמביאה תוצאות.",
    icon: Globe,
  },
];

const Services: React.FC = () => {
  return (
    <section className="relative py-20 bg-gradient-to-br from-black via-indigo-950 to-purple-950 text-white overflow-hidden">
      <div className="container mx-auto px-6">
        {/* כותרת */}
        <motion.h2
          className="text-4xl md:text-5xl font-bold text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          השירותים שלנו
        </motion.h2>

        {/* גריד שירותים */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 shadow-lg hover:shadow-indigo-500/30 transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                {/* אייקון מונפש */}
                <motion.div
                  className="flex justify-center mb-4"
                  animate={{
                    scale: [1, 1.15, 1],
                    opacity: [1, 0.9, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <Icon size={36} className="text-indigo-400" />
                </motion.div>
                <h3 className="text-xl font-bold text-center mb-2">{service.title}</h3>
                <p className="text-sm text-gray-300 text-center">{service.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services; 