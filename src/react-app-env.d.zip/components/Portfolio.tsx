import React, { useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize2 } from 'lucide-react';

const Portfolio: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const portfolioItems = [
    { id: 1, title: "אתר מסחר אלקטרוני", category: "Web Design" },
    { id: 2, title: "קמפיין פייסבוק", category: "Digital Marketing" },
    { id: 3, title: "אפליקציה עם AI", category: "App Development" },
    { id: 4, title: "קליפ מוזיקלי", category: "Video Production" },
    { id: 5, title: "אתר תדמית", category: "Web Design" },
    { id: 6, title: "קמפיין גוגל", category: "Digital Marketing" }
  ];

  return (
    <section className="section portfolio" id="portfolio">
      <div className="container">
        <h2 className="section-title">עבודות <span>מובילות</span></h2>
        <p className="section-subtitle">
          גלו את הפרויקטים הגדולים – אתרים, קליפים, קמפיינים וקריינות שיצרו תגובות
        </p>

        {/* Main Video Player */}
        <div className="video-player">
          <div style={{ textAlign: 'center' }}>
            <div style={{
              width: '6rem',
              height: '6rem',
              background: 'rgba(168, 85, 247, 0.2)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1rem'
            }}>
              <Play size={48} color="#a855f7" />
            </div>
            <p style={{ color: '#9ca3af', fontSize: '1.125rem' }}>Showreel Video</p>
            <p style={{ color: '#6b7280', fontSize: '0.875rem' }}>הצגת עבודות מובילות</p>
          </div>

          {/* Video Controls */}
          <div style={{
            position: 'absolute',
            bottom: '1rem',
            left: '1rem',
            right: '1rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button
                style={{
                  width: '3rem',
                  height: '3rem',
                  background: 'rgba(0, 0, 0, 0.5)',
                  borderRadius: '50%',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer'
                }}
                onClick={() => setIsPlaying(!isPlaying)}
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>
              
              <button
                style={{
                  width: '2.5rem',
                  height: '2.5rem',
                  background: 'rgba(0, 0, 0, 0.5)',
                  borderRadius: '50%',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer'
                }}
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
            </div>

            <button
              style={{
                width: '2.5rem',
                height: '2.5rem',
                background: 'rgba(0, 0, 0, 0.5)',
                borderRadius: '50%',
                border: 'none',
                color: 'white',
                cursor: 'pointer'
              }}
            >
              <Maximize2 size={16} />
            </button>
          </div>
        </div>

        {/* Portfolio Gallery */}
        <div className="portfolio-gallery">
          {portfolioItems.map((item) => (
            <div key={item.id} className="portfolio-item">
              <div style={{ textAlign: 'center' }}>
                <h3 style={{ color: 'white', fontWeight: 'bold', fontSize: '1.125rem', marginBottom: '0.25rem' }}>
                  {item.title}
                </h3>
                <p style={{ color: '#a855f7', fontSize: '0.875rem' }}>{item.category}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio; 