import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Monitor, Search, Target } from "lucide-react";

const rotatingWords = [
  "בניית אתרים",
  "ניהול קמפיינים",
  "חדשנות דיגיטלית",
];

const glassCards = [
  { id: 1, title: "UX / UI", description: "עיצוב חוויית משתמש מודרנית", icon: Monitor },
  { id: 2, title: "SEO", description: "אופטימיזציה לקידום אתרים", icon: Search },
  { id: 3, title: "Campaigns", description: "ניהול קמפיינים מתקדמים", icon: Target },
];

const Hero: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [currentWord, setCurrentWord] = useState(0);
  const [glowPosition, setGlowPosition] = useState({ x: 0, y: 0 });

  // פרלקס לעכבר
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 20;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;

      setMousePosition({ x, y });
      setGlowPosition({ x: e.clientX, y: e.clientY });
    };

    if (window.innerWidth > 768) {
      window.addEventListener("mousemove", handleMouseMove);
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  // מילים מתחלפות
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWord((prev) => (prev + 1) % rotatingWords.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative flex items-center justify-center min-h-screen overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-black text-white">
      {/* רקע מונפש */}
      <motion.div
        className="absolute inset-0 z-0"
        animate={{
          background: [
            "linear-gradient(135deg, #1e3a8a, #6d28d9)",
            "linear-gradient(135deg, #6d28d9, #1e40af)",
            "linear-gradient(135deg, #1e3a8a, #6d28d9)",
          ],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          repeatType: "reverse",
        }}
      />

      {/* Glow אינטראקטיבי */}
      {window.innerWidth > 768 && (
        <motion.div
          className="pointer-events-none absolute w-96 h-96 rounded-full bg-purple-500 opacity-20 blur-3xl"
          style={{
            left: glowPosition.x - 200,
            top: glowPosition.y - 200,
          }}
          animate={{
            x: glowPosition.x - 200,
            y: glowPosition.y - 200,
          }}
          transition={{ type: "spring", stiffness: 100, damping: 30 }}
        />
      )}

      {/* כרטיסי Glassmorphism עם אייקונים מונפשים */}
      {glassCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <motion.div
            key={card.id}
            className="absolute bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 w-48 text-center shadow-lg"
            style={{
              top: `${20 + index * 25}%`,
              left: index % 2 === 0 ? "10%" : "auto",
              right: index % 2 !== 0 ? "10%" : "auto",
            }}
            animate={{
              y: [0, 10, 0],
            }}
            transition={{
              duration: 6 + index,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <motion.div
              className="flex justify-center mb-2"
              animate={{
                scale: [1, 1.15, 1],
                opacity: [1, 0.9, 1],
              }}
              transition={{
                duration: 2 + index,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <Icon size={28} className="text-indigo-400" />
            </motion.div>
            <h4 className="text-lg font-bold text-white">{card.title}</h4>
            <p className="text-sm text-gray-300">{card.description}</p>
          </motion.div>
        );
      })}

      {/* תוכן הירו */}
      <div className="relative z-10 text-center px-6 max-w-4xl">
        <motion.h1
          className="text-4xl md:text-6xl font-bold mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          צוות עילית מקצועי ל־
          <span className="block h-12 relative overflow-hidden mt-2">
            <AnimatePresence mode="wait">
              <motion.span
                key={rotatingWords[currentWord]}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.6 }}
                className="absolute left-0 right-0 text-indigo-400"
              >
                {rotatingWords[currentWord]}
              </motion.span>
            </AnimatePresence>
          </span>
        </motion.h1>

        <motion.p
          className="text-lg md:text-2xl text-gray-200 mb-10 leading-relaxed"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
        >
          עם רקע אמנותי בכתיבה ומוזיקה, ניסיון של מעל 25 שנה בחדשנות ויזמות,
          וניהול קמפיינים דיגיטליים בהיקפים של מיליונים – אנחנו הופכים רעיונות לדיגיטל שמייצר הצלחה.
        </motion.p>

        {/* כפתורי פעולה */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
        >
          <a
            href="#contact"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-full font-semibold shadow-lg transition transform hover:scale-105"
          >
            בואו נבנה את האתר שלכם
          </a>
          <a
            href="#portfolio"
            className="border border-white hover:bg-white hover:text-indigo-900 px-8 py-4 rounded-full font-semibold transition transform hover:scale-105"
          >
            צפו בעבודות שלנו
          </a>
        </motion.div>
      </div>

      {/* אלמנטים צפים עם פרלקס */}
      <motion.div
        className="absolute top-10 left-10 w-32 h-32 bg-purple-500 rounded-full opacity-30 blur-2xl"
        animate={{
          x: mousePosition.x,
          y: mousePosition.y,
        }}
        transition={{ type: "spring", stiffness: 50, damping: 20 }}
      />
      <motion.div
        className="absolute bottom-10 right-10 w-40 h-40 bg-indigo-500 rounded-full opacity-30 blur-2xl"
        animate={{
          x: -mousePosition.x,
          y: -mousePosition.y,
        }}
        transition={{ type: "spring", stiffness: 50, damping: 20 }}
      />
    </section>
  );
};

export default Hero; 