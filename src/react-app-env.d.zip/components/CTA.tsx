import React from 'react';
import { Phone, Mail, MessageCircle, ArrowRight } from 'lucide-react';

const CTA: React.FC = () => {
  const contactMethods = [
    {
      icon: Phone,
      title: 'טלפון',
      value: '+972-50-123-4567',
      href: 'tel:+972501234567'
    },
    {
      icon: Mail,
      title: 'אימייל',
      value: 'elad@example.com',
      href: 'mailto:elad@example.com'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      value: 'צור קשר ישיר',
      href: 'https://wa.me/972501234567'
    }
  ];

  return (
    <section className="section cta" id="contact">
      <div className="container">
        <h2 className="section-title">
          מוכן לשנות את <span>המציאות הדיגיטלית</span> שלך?
        </h2>
        <p className="section-subtitle">
          בין אם זה אתר, קמפיין, הדרכה או אפליקציה – תקבל מוצר שלם, בזמן מהיר ובמחיר משתלם.
        </p>

        {/* Main CTA Button */}
        <a href="#contact" className="cta-btn">
          צרו קשר עכשיו
          <ArrowRight size={24} />
        </a>

        {/* Contact Methods */}
        <div className="contact-methods">
          {contactMethods.map((method) => (
            <a
              key={method.title}
              href={method.href}
              className="contact-method"
            >
              <div className="contact-icon">
                <method.icon size={24} />
              </div>
              
              <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: 'white', marginBottom: '0.5rem' }}>
                {method.title}
              </h3>
              <p style={{ color: '#d1d5db' }}>
                {method.value}
              </p>
            </a>
          ))}
        </div>

        {/* Footer Note */}
        <div style={{ textAlign: 'center', marginTop: '4rem' }}>
          <p style={{ color: '#9ca3af' }}>
            זמין 24/7 לשיחות ייעוץ חינם • תשובה תוך שעה • מחיר משתלם
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA; 