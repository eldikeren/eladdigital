import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: "דוד כהן",
      company: "חברת טכנולוגיה",
      text: "אלעד יצר עבורנו אתר מדהים תוך זמן קצר. התוצאות מעל ומעבר לציפיות!",
      rating: 5
    },
    {
      name: "שרה לוי",
      company: "סטארט-אפ",
      text: "הקמפיין שיצר אלעד הכפיל את המכירות שלנו תוך חודש. מומלץ בחום!",
      rating: 5
    },
    {
      name: "משה ישראלי",
      company: "עסק מקומי",
      text: "שירות מקצועי, תקשורת מעולה ותוצאות מדהימות. אלעד הוא הטוב ביותר!",
      rating: 5
    }
  ];

  const stats = [
    { number: "100+", label: "לקוחות מרוצים" },
    { number: "98%", label: "שביעות רצון" },
    { number: "50+", label: "פרויקטים מוצלחים" },
    { number: "24/7", label: "תמיכה זמינה" }
  ];

  return (
    <section className="section testimonials" id="testimonials">
      <div className="container">
        <h2 className="section-title">לקוחות <span>שממליצים</span></h2>
        <p className="section-subtitle">
          עבודה עם לקוחות רבים שהפכו לפרויקטים מצליחים – גם במחיר נגיש ובקצב עבודה מהיר
        </p>

        {/* Testimonials Grid */}
        <div className="testimonials-grid">
          {testimonials.map((testimonial) => (
            <div key={testimonial.name} className="testimonial-card">
              <div className="stars">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={20} fill="currentColor" />
                ))}
              </div>
              
              <Quote size={32} color="#a855f7" style={{ marginBottom: '1rem' }} />
              <p className="testimonial-text">{testimonial.text}</p>
              
              <div>
                <h4 className="testimonial-author">{testimonial.name}</h4>
                <p className="testimonial-company">{testimonial.company}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Statistics */}
        <div style={{
          marginTop: '4rem',
          background: 'linear-gradient(135deg, #a855f7 0%, #8b5cf6 100%)',
          borderRadius: '1rem',
          padding: '2rem'
        }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '2rem'
          }}>
            {stats.map((stat) => (
              <div key={stat.label} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '3rem', fontWeight: 'bold', color: 'white', marginBottom: '0.5rem' }}>
                  {stat.number}
                </div>
                <div style={{ color: '#e9d5ff' }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials; 